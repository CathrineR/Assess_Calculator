﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace Ramasala.Calculator
{
    public class CalculatorViewModel : INotifyPropertyChanged
    {
        private string _displayText;

        public string DisplayText
        {
            get { return _displayText; }
            set
            {
                _displayText = value;
                OnPropertyChanged();
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}