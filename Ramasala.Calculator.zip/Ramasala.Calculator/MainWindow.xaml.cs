﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace Ramasala.Calculator;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
    private decimal _currentValue = 0;
    private decimal _memoryValue = 0;
    private string _pendingOperation = "";
    private bool _newNumberEntered = false;
    private readonly List<string> _history = [];
    private readonly CalculatorViewModel _dataContext;

    public MainWindow()
    {
        InitializeComponent();

        _dataContext = new CalculatorViewModel();
        DataContext = _dataContext;
    }

    private void DigitButton_Click(object sender, RoutedEventArgs e)
    {
        string digit = (sender as Button).Content.ToString();
        if (_newNumberEntered)
        {
            _dataContext.DisplayText = digit;
            _newNumberEntered = false;
        }
        else
        {
            _dataContext.DisplayText += digit;
        }
    }

    private void UpdateDisplay()
    {
        DisplayTextBlock.Text = _dataContext.DisplayText;
    }

    private void OperationButton_Click(object sender, RoutedEventArgs e)
    {
        _pendingOperation = (sender as Button).Content.ToString();
        DoOperation(_pendingOperation);
    }

    private void DoOperation(string operation)
    {
        if (!string.IsNullOrEmpty(operation))
        {
            _pendingOperation = operation;
            PerformOperation();
        }
        else
        {
            _currentValue = decimal.Parse(_dataContext.DisplayText);
        }

        _pendingOperation = operation;
        _newNumberEntered = true;
    }

    private void MemorySubtractButton_Click(object sender, RoutedEventArgs e)
    {
        _memoryValue -= decimal.Parse(_dataContext.DisplayText);
    }

    private void MemoryAddButton_Click(object sender, RoutedEventArgs e)
    {
        _memoryValue += decimal.Parse(_dataContext.DisplayText);
    }

    private void EqualsButton_Click(object sender, RoutedEventArgs e)
    {
        if (!string.IsNullOrEmpty(_pendingOperation))
        {
            PerformOperation();
            _pendingOperation = "";
        }
    }

    private void ClearEntryButton_Click(object sender, RoutedEventArgs e)
    {
        _dataContext.DisplayText = "0";
        UpdateDisplay();
    }

    private void ClearAllButton_Click(object sender, RoutedEventArgs e)
    {
        _dataContext.DisplayText = "0";
        _currentValue = 0;
        _pendingOperation = "";
        _newNumberEntered = true;
        UpdateDisplay();
    }

    private void DecimalButton_Click(object sender, RoutedEventArgs e)
    {
        if (!_dataContext.DisplayText.Contains('.'))
        {
            _dataContext.DisplayText += ".";
            UpdateDisplay();
        }
    }

    private void MemoryRecallButton_Click(object sender, RoutedEventArgs e)
    {
        _dataContext.DisplayText = _memoryValue.ToString();
        UpdateDisplay();
        _newNumberEntered = true;
    }

    private void HistoryButton_Click(object sender, RoutedEventArgs e)
    {
        if (HistoryListBox.Visibility == Visibility.Visible)
        {
            HistoryListBox.Visibility = Visibility.Collapsed;
        }
        else
        {
            HistoryListBox.Visibility = Visibility.Visible;
        }
    }

    private void PerformOperation()
    {
        switch (_pendingOperation)
        {
            case "+":
                _currentValue += decimal.Parse(_dataContext.DisplayText);
                break;
            case "-":
                _currentValue -= decimal.Parse(_dataContext.DisplayText);
                break;
            case "*":
                _currentValue *= decimal.Parse(_dataContext.DisplayText);
                break;
            case "/":
                _currentValue /= decimal.Parse(_dataContext.DisplayText);
                break;
        }
        _dataContext.DisplayText = _currentValue.ToString();
        _pendingOperation = "";
        _newNumberEntered = true;
        UpdateHistory();
    }

    private void Window_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Enter)
        {
            EqualsButton_Click(null, null);
        }
        else if (e.Key == Key.Back)
        {
            ClearEntryButton_Click(null, null);
        }
        else if (e.Key == Key.Delete)
        {
            ClearAllButton_Click(null, null);
        }
        else if (e.Key == Key.OemPeriod)
        {
            DecimalButton_Click(null, null);
        }
        else if (e.Key == Key.Add)
        {
            DoOperation("+");
        }
        else if (e.Key == Key.Subtract)
        {
            DoOperation("-");
        }
        else if (e.Key == Key.Multiply)
        {
            DoOperation("*");
        }
        else if (e.Key == Key.Divide)
        {
            DoOperation("/");
        }
        else if (e.Key == Key.M)
        {
            MemoryAddButton_Click(null, null);
        }
        else if (e.Key == Key.N)
        {
            MemorySubtractButton_Click(null, null);
        }
        else if (e.Key == Key.R)
        {
            MemoryRecallButton_Click(null, null);
        }
        else if (e.Key == Key.H)
        {
            HistoryButton_Click(null, null);
        }
        else if (e.Key >= Key.D0 && e.Key <= Key.D9)
        {
            int digitIndex = (int)e.Key - (int)Key.D0;
            SimulateDigitButtonClick(digitIndex);
        }
        else if (e.Key >= Key.NumPad0 && e.Key <= Key.NumPad9)
        {
            int digitIndex = (int)e.Key - (int)Key.NumPad0;
            SimulateDigitButtonClick(digitIndex);
        }
    }

    private void SimulateDigitButtonClick(int digitIndex)
    {
        string digit = digitIndex.ToString();
        if (_newNumberEntered)
        {
            _dataContext.DisplayText = digit;
            _newNumberEntered = false;
        }
        else
        {
            _dataContext.DisplayText += digit;
        }
    }

    private void UpdateHistory()
    {
        _history.Add($"{_currentValue} {_pendingOperation} {_dataContext.DisplayText} = {_currentValue}");
        HistoryListBox.ItemsSource = _history;
    }
}